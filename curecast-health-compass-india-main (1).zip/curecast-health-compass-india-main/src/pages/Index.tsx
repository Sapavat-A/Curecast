
import ChatInterface from '../components/chatbot/ChatInterface';
import { useUser } from '@/contexts/UserContext';
import { Navigate } from 'react-router-dom';

const Index = () => {
  const { isAuthenticated } = useUser();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }
  
  return (
    <div className="h-[calc(100vh-120px)]">
      <ChatInterface />
    </div>
  );
};

export default Index;
